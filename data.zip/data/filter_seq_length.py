infile = open("train_depleted_all.csv")
outfile = open("train_depleted_all_50.csv","w")

for line in infile:
    if line.startswith("protein"):
        outfile.write(line)
        continue
    splitline = line.strip().split(",")
    if len(splitline[10]) > 49:
        outfile.write(line)
outfile.close()

infile = open("train_enriched_all.csv")
outfile = open("train_enriched_all_50.csv","w")

for line in infile:
    if line.startswith("protein"):
        outfile.write(line)
        continue
    splitline = line.strip().split(",")
    if len(splitline[10]) > 49:
        outfile.write(line)
outfile.close()